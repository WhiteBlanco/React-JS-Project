import React, { Component }  from 'react';

import Button from './../../components/Button/Button'
import Card from './../../components/Card/Card'

class SearchPage extends Component {

  render() {
    //const props = { label: "CLICK", id: 'button1'}
    //return Button(props);
    return <div className="page-search">
      <div className="search-box">
        <input />
        <Button 
          id="button-search"
          label="Search"
          disabled={false}
          onClick={() => alert()}
        />
      </div>
      <div className="results-box">
        <Card title="risultato" description="Lunga descrizione mega-interessante"/> {/* CARD che accetta title e description */}
      </div>
    </div>;
  }
}

export default SearchPage;