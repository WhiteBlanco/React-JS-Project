import React from 'react';

// Componente specificato come funzione classica
function Button0(props) {
  return <button>{props.label}</button>;
}

// Componente specificato come arrow function
const Button1 = (props) => {
  return <button>{props.label}</button>;
}

// Aggiunta variabile per props label
const Button2 = (props) => {
  const label = props.label;
  return <button>{label}</button>;
}

// Props hanno questo aspetto
// const props = {
//   label: "CLICK"
// };

// Aggiunta destrutturazione dell'oggetto props
const Button3 = (props) => {
  //const label = props.label;
  //const id = props.id;
  const { label, id } = props;
  return <button id={id}>{label}</button>;
}

const funcArr = () => {
  console.log('executed');
  let num = 1 + 1;
  return num
};

// Destrutturazione all'interno degli argomenti di funzione
// const { label } = props; // questo non serve più
const Button = ({ id, label, disabled = false, onClick }) => {
  return <button id={id} disabled={disabled} onClick={onClick}>
           {label}
         </button>;
}

export default Button;