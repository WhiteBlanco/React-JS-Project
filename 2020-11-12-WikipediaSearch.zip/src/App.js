import React from 'react';

import SearchPage from './pages/Search/Search.page';

import './App.css';

function App() {
  return <SearchPage />;
}

export default App;
